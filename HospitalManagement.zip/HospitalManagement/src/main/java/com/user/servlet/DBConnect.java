package com.user.servlet;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnect {
    private static Connection conn;

    public static Connection getconn() {
        try {
            // Load the JDBC driver (optional for JDBC 4.0+)
            // Class.forName("com.mysql.jdbc.Driver");

            // Establish the database connection
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management", "root", "Abhishek11");
            System.out.println("Connected to database successfully");

        } catch (SQLException e) {
            // Handle database connection errors gracefully
            e.printStackTrace(); // For debugging, consider using a logging framework
        }
        return conn;
    }

}